package com.example.lensreminder

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val CHANNEL_ID = "lens_reminders"
private const val PREFS = "lens_reminder_prefs"
private const val KEY_START = "start_ms"
private const val KEY_PERIOD = "period_days"
private const val KEY_HOUR = "hour"
private const val KEY_MINUTE = "minute"
private const val KEY_STOCK = "stock"
private const val REQUEST_CODE_REPLACE = 4401
private const val REQUEST_CODE_BUY = 4402

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            LensReminderTheme { LensApp() }
        }
    }
}

@Composable
private fun LensReminderTheme(content: @Composable () -> Unit) {
    val colors = androidx.compose.material3.darkColorScheme(
        primary = Color(0xFF8B7CFF),
        onPrimary = Color.White,
        secondary = Color(0xFF55D6FF),
        tertiary = Color(0xFFB8F397),
        background = Color(0xFF090B10),
        surface = Color(0xFF141720),
        surfaceVariant = Color(0xFF202431),
        onSurfaceVariant = Color(0xFFADB4C3)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LensApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    var periodDays by remember { mutableStateOf(prefs.getInt(KEY_PERIOD, 30)) }
    var reminderHour by remember { mutableStateOf(prefs.getInt(KEY_HOUR, 9)) }
    var reminderMinute by remember { mutableStateOf(prefs.getInt(KEY_MINUTE, 0)) }
    var startMs by remember { mutableStateOf(prefs.getLong(KEY_START, 0L)) }
    var stock by remember { mutableStateOf(prefs.getInt(KEY_STOCK, 0)) }
    var showPeriodMenu by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }
    var showPurchaseDialog by remember { mutableStateOf(false) }
    var purchaseAmount by remember { mutableStateOf("10") }

    fun saveSettings(
        newStart: Long = startMs,
        newPeriod: Int = periodDays,
        newHour: Int = reminderHour,
        newMinute: Int = reminderMinute,
        newStock: Int = stock
    ) {
        startMs = newStart
        periodDays = newPeriod
        reminderHour = newHour
        reminderMinute = newMinute
        stock = newStock.coerceAtLeast(0)
        prefs.edit()
            .putLong(KEY_START, newStart)
            .putInt(KEY_PERIOD, newPeriod)
            .putInt(KEY_HOUR, newHour)
            .putInt(KEY_MINUTE, newMinute)
            .putInt(KEY_STOCK, stock)
            .apply()
        if (newStart > 0L) {
            ReminderScheduler.schedule(context, newStart, newPeriod, newHour, newMinute)
        }
    }

    val nextDate = if (startMs > 0L) calculateNext(startMs, periodDays, reminderHour, reminderMinute) else null
    val daysLabel = if (stock == 1) "лінза" else "лінз"

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(17.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF8B7CFF), Color(0xFF55D6FF)))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = "Lens Reminder", tint = Color.White, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Lens Reminder", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Лінзи під контролем", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("НАСТУПНА ЗАМІНА", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                    Text(
                        nextDate?.let { formatDateTime(it) } ?: "Ще не налаштовано",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text("кожні $periodDays днів • %02d:%02d".format(reminderHour, reminderMinute), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Inventory2, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Залишок лінз", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Після кожної заміни кількість зменшується на 1", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        Text("$stock", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    }

                    if (stock == 1) {
                        Text("⚠ Залишилася 1 лінза — час купити нові.", color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold)
                    } else if (stock == 0) {
                        Text("Лінз немає. Додайте покупку перед наступною заміною.", color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = { showPurchaseDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(15.dp)
                    ) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Додати лінзи після покупки")
                    }
                }
            }

            Text("Налаштування", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Період заміни", fontWeight = FontWeight.SemiBold)
                    ExposedDropdownMenuBox(
                        expanded = showPeriodMenu,
                        onExpandedChange = { showPeriodMenu = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = "$periodDays днів",
                            onValueChange = {},
                            readOnly = true,
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        DropdownMenu(expanded = showPeriodMenu, onDismissRequest = { showPeriodMenu = false }) {
                            listOf(7, 14, 30, 60, 90).forEach { days ->
                                DropdownMenuItem(
                                    text = { Text("$days днів") },
                                    onClick = {
                                        showPeriodMenu = false
                                        val start = if (startMs == 0L) System.currentTimeMillis() else startMs
                                        saveSettings(start, days)
                                    }
                                )
                            }
                        }
                    }

                    Text("Час нагадування", fontWeight = FontWeight.SemiBold)
                    OutlinedButton(onClick = { showTimePicker = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
                        Icon(Icons.Default.Alarm, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("%02d:%02d".format(reminderHour, reminderMinute))
                    }
                }
            }

            Button(
                onClick = {
                    if (stock > 0) {
                        val newStock = stock - 1
                        val now = System.currentTimeMillis()
                        saveSettings(now, periodDays, reminderHour, reminderMinute, newStock)
                        if (newStock == 1) ReminderNotifications.showPurchaseReminder(context)
                        if (newStock == 0) ReminderNotifications.showEmptyReminder(context)
                    }
                },
                enabled = stock > 0,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(17.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (startMs == 0L) "Замінити та почати цикл" else "Замінити лінзи сьогодні", fontWeight = FontWeight.Bold)
            }

            if (startMs == 0L) {
                OutlinedButton(
                    onClick = { saveSettings(System.currentTimeMillis(), periodDays, reminderHour, reminderMinute, stock) },
                    enabled = stock > 0,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(17.dp)
                ) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Встановити дату без списання")
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp)) {
                Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.width(8.dp))
                Text("Нагадування працюють після закриття застосунку.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(6.dp))
        }
    }

    if (showPurchaseDialog) {
        AlertDialog(
            onDismissRequest = { showPurchaseDialog = false },
            title = { Text("Нова покупка") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Скільки лінз додати до залишку?")
                    OutlinedTextField(
                        value = purchaseAmount,
                        onValueChange = { value -> purchaseAmount = value.filter(Char::isDigit).take(4) },
                        singleLine = true,
                        label = { Text("Кількість") }
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val amount = purchaseAmount.toIntOrNull() ?: 0
                    if (amount > 0) saveSettings(newStock = stock + amount)
                    showPurchaseDialog = false
                }) { Text("Додати") }
            },
            dismissButton = { OutlinedButton(onClick = { showPurchaseDialog = false }) { Text("Скасувати") } }
        )
    }

    if (showTimePicker) {
        val state = rememberTimePickerState(initialHour = reminderHour, initialMinute = reminderMinute, is24Hour = true)
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                Button(onClick = {
                    showTimePicker = false
                    val start = if (startMs == 0L) System.currentTimeMillis() else startMs
                    saveSettings(start, periodDays, state.hour, state.minute)
                }) { Text("Зберегти") }
            },
            dismissButton = { OutlinedButton(onClick = { showTimePicker = false }) { Text("Скасувати") } },
            text = { TimePicker(state = state) }
        )
    }
}

private fun calculateNext(startMs: Long, periodDays: Int, hour: Int, minute: Int): Long {
    val calendar = Calendar.getInstance().apply { timeInMillis = startMs }
    calendar.add(Calendar.DAY_OF_YEAR, periodDays)
    calendar.set(Calendar.HOUR_OF_DAY, hour)
    calendar.set(Calendar.MINUTE, minute)
    calendar.set(Calendar.SECOND, 0)
    calendar.set(Calendar.MILLISECOND, 0)
    while (calendar.timeInMillis <= System.currentTimeMillis()) calendar.add(Calendar.DAY_OF_YEAR, periodDays)
    return calendar.timeInMillis
}

private fun formatDateTime(timeMs: Long): String =
    SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.getDefault()).format(Date(timeMs))

object ReminderScheduler {
    fun schedule(context: Context, startMs: Long, periodDays: Int, hour: Int, minute: Int) {
        val triggerAt = calculateNext(startMs, periodDays, hour, minute)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context, REQUEST_CODE_REPLACE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pending)
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
    }
}

object ReminderNotifications {
    fun showPurchaseReminder(context: Context) {
        notify(context, REQUEST_CODE_BUY, "Час купити лінзи", "Залишилася 1 лінза. Додайте нову покупку в Lens Reminder.")
    }

    fun showEmptyReminder(context: Context) {
        notify(context, REQUEST_CODE_BUY + 1, "Лінзи закінчилися", "Додайте нову покупку перед наступною заміною.")
    }

    private fun notify(context: Context, id: Int, title: String, text: String) {
        createNotificationChannel(context)
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = android.app.Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(id, notification)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        createNotificationChannel(context)
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = android.app.Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Час замінити лінзи")
            .setContentText("Замініть лінзи та натисніть «Замінити лінзи сьогодні», щоб списати 1 шт.")
            .setAutoCancel(true)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(REQUEST_CODE_REPLACE, notification)
    }
}

private fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Нагадування про лінзи",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Нагадування про заміну та покупку контактних лінз" }
        )
    }
}
