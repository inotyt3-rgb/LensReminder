package com.example.lensreminder

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.appwidget.AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT
import android.appwidget.AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LensReminderWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateWidget(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle
    ) {
        updateWidget(context, appWidgetManager, appWidgetId, newOptions)
    }

    override fun onEnabled(context: Context) {
        updateAll(context)
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, LensReminderWidget::class.java)
            manager.getAppWidgetIds(component).forEach { updateWidget(context, manager, it) }
        }

        private fun updateWidget(
            context: Context,
            manager: AppWidgetManager,
            appWidgetId: Int,
            options: android.os.Bundle? = null
        ) {
            val actualOptions = options ?: manager.getAppWidgetOptions(appWidgetId)
            val width = actualOptions.getInt(OPTION_APPWIDGET_MIN_WIDTH, 110)
            val height = actualOptions.getInt(OPTION_APPWIDGET_MIN_HEIGHT, 55)
            val layout = when {
                height >= 180 && width >= 150 -> R.layout.widget_2x2
                width >= 240 -> R.layout.widget_4x1
                else -> R.layout.widget_2x1
            }

            val views = RemoteViews(context.packageName, layout)
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val stock = prefs.getInt(KEY_STOCK, 0)
            val startMs = prefs.getLong(KEY_START, 0L)
            val periodDays = prefs.getInt(KEY_PERIOD, 30)
            val hour = prefs.getInt(KEY_HOUR, 9)
            val minute = prefs.getInt(KEY_MINUTE, 0)

            val next = if (startMs > 0L) {
                ReminderScheduler.getNextReplacementTime(context, startMs, periodDays, hour, minute)
            } else null

            val bg = when {
                stock <= 0 -> R.drawable.widget_bg_empty
                stock == 1 -> R.drawable.widget_bg_warning
                else -> R.drawable.widget_bg
            }
            views.setInt(R.id.widget_root, "setBackgroundResource", bg)
            views.setTextViewText(R.id.widget_stock, if (layout == R.layout.widget_2x2) "$stock\nшт." else "$stock шт.")
            views.setTextViewText(
                R.id.widget_next,
                next?.let {
                    if (layout == R.layout.widget_4x1) formatDateTime(it) else formatDate(it)
                } ?: "Налаштуйте дату заміни"
            )

            val statusId = context.resources.getIdentifier("widget_status", "id", context.packageName)
            if (statusId != 0) {
                val status = when {
                    stock <= 0 -> "Потрібно купити"
                    stock == 1 -> "Купіть лінзи"
                    else -> "Усе добре"
                }
                val statusColor = when {
                    stock <= 0 -> android.graphics.Color.rgb(255, 105, 120)
                    stock == 1 -> android.graphics.Color.rgb(255, 177, 72)
                    else -> android.graphics.Color.rgb(118, 230, 178)
                }
                views.setTextViewText(statusId, status)
                views.setTextColor(statusId, statusColor)
            }

            val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pending = PendingIntent.getActivity(
                context,
                appWidgetId,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(appWidgetId, views)
        }

        private fun formatDate(timeMs: Long): String =
            SimpleDateFormat("dd MMM yyyy", Locale("uk", "UA")).format(Date(timeMs))

        private fun formatDateTime(timeMs: Long): String =
            SimpleDateFormat("dd MMM yyyy • HH:mm", Locale("uk", "UA")).format(Date(timeMs))
    }
}
