package com.example.lensreminder

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private const val CHANNEL_ID = "lens_reminders"
private const val PREFS = "lens_reminder_prefs"
private const val KEY_START = "start_ms"
private const val KEY_PERIOD = "period_days"
private const val KEY_HOUR = "hour"
private const val KEY_MINUTE = "minute"
private const val KEY_STOCK = "stock"
private const val REQUEST_CODE_REPLACE = 4401
private const val REQUEST_CODE_BUY = 4402
private const val ACTION_REPLACE = "com.example.lensreminder.REPLACE"
private const val ACTION_SYSTEM_ALARM_CHANGED = AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED

private val Cream = Color(0xFFF1EEE5)
private val Ink = Color(0xFF202020)
private val MutedInk = Color(0xFF77736A)
private val AppBlack = Color(0xFF111111)
private val CardBlack = Color(0xFF1A1A1A)
private val SoftBlack = Color(0xFF262626)
private val Accent = Color(0xFFD6CDBB)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        ReminderScheduler.syncReplacementWithSystemAlarm(this)

        setContent { LensReminderTheme { LensApp() } }
    }

    private val systemAlarmReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent?) {
            if (intent?.action == ACTION_SYSTEM_ALARM_CHANGED) {
                ReminderScheduler.syncReplacementWithSystemAlarm(context)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = android.content.IntentFilter(ACTION_SYSTEM_ALARM_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(systemAlarmReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(systemAlarmReceiver, filter)
        }
        ReminderScheduler.syncReplacementWithSystemAlarm(this)
    }

    override fun onStop() {
        unregisterReceiver(systemAlarmReceiver)
        super.onStop()
    }
}

@Composable
private fun LensReminderTheme(content: @Composable () -> Unit) {
    val colors = androidx.compose.material3.darkColorScheme(
        primary = Cream,
        onPrimary = Ink,
        secondary = Accent,
        onSecondary = Ink,
        background = AppBlack,
        surface = CardBlack,
        surfaceVariant = SoftBlack,
        onSurface = Color.White,
        onSurfaceVariant = Color(0xFFB9B5AC)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LensApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    var periodDays by remember { mutableStateOf(prefs.getInt(KEY_PERIOD, 30)) }
    var reminderHour by remember { mutableStateOf(prefs.getInt(KEY_HOUR, 9)) }
    var reminderMinute by remember { mutableStateOf(prefs.getInt(KEY_MINUTE, 0)) }
    var startMs by remember { mutableStateOf(prefs.getLong(KEY_START, 0L)) }
    var stock by remember { mutableStateOf(prefs.getInt(KEY_STOCK, 0)) }

    var showPeriodMenu by remember { mutableStateOf(false) }
    var showReminderTimePicker by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showPurchaseDialog by remember { mutableStateOf(false) }
    var purchaseAmount by remember { mutableStateOf("10") }

    fun persist(
        newStart: Long = startMs,
        newPeriod: Int = periodDays,
        newHour: Int = reminderHour,
        newMinute: Int = reminderMinute,
        newStock: Int = stock
    ) {
        startMs = newStart
        periodDays = newPeriod
        reminderHour = newHour
        reminderMinute = newMinute
        stock = newStock.coerceAtLeast(0)
        prefs.edit()
            .putLong(KEY_START, startMs)
            .putInt(KEY_PERIOD, periodDays)
            .putInt(KEY_HOUR, reminderHour)
            .putInt(KEY_MINUTE, reminderMinute)
            .putInt(KEY_STOCK, stock)
            .apply()
        if (startMs > 0L) {
            ReminderScheduler.scheduleReplacement(context, startMs, periodDays, reminderHour, reminderMinute)
        }
    }

    val nextDate = if (startMs > 0L) ReminderScheduler.getNextReplacementTime(context, startMs, periodDays, reminderHour, reminderMinute) else null
    val systemAlarmTime = remember { ReminderScheduler.getNextSystemAlarmTime(context) }
    val daysLeft = nextDate?.let { TimeUnit.MILLISECONDS.toDays((it - System.currentTimeMillis()).coerceAtLeast(0L)).toInt() }

    Surface(modifier = Modifier.fillMaxSize(), color = AppBlack) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(top = 8.dp, bottom = 14.dp)
                .statusBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header inspired by the supplied reference: compact, premium, minimal.
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(15.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF343434), Color(0xFF181818))))
                        .border(1.dp, Color(0xFF4A4A4A), RoundedCornerShape(15.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = "Lens Reminder", tint = Cream, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Lens Reminder", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                    Text("Лінзи під контролем", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
                androidx.compose.material3.IconButton(
                    onClick = { showSettingsDialog = true },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(SoftBlack)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = "Налаштування", tint = Cream, modifier = Modifier.size(21.dp))
                }
            }

            // Main hero card.
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(containerColor = Cream)
            ) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("НАСТУПНА ЗАМІНА", color = MutedInk, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Ink)
                                .padding(horizontal = 11.dp, vertical = 6.dp)
                        ) {
                            Text("LIVE", color = Cream, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            daysLeft?.toString() ?: "—",
                            color = Ink,
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("днів", color = MutedInk, modifier = Modifier.padding(bottom = 9.dp), style = MaterialTheme.typography.titleMedium)
                    }
                    Text(
                        nextDate?.let { formatDateTime(it) } ?: "Додайте покупку та почніть цикл",
                        color = Ink,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Alarm, contentDescription = null, tint = MutedInk, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(7.dp))
                        Text("кожні $periodDays днів • %02d:%02d".format(reminderHour, reminderMinute), color = MutedInk, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            // Stock card: 2 lenses are consumed on each replacement.
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = CardBlack)
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(SoftBlack),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Inventory2, contentDescription = null, tint = Cream)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Залишок", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Після заміни списується 2 лінзи", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(stock.toString(), color = Cream, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StockAdjustButton(icon = Icons.Default.Remove, enabled = stock > 0) { persist(newStock = stock - 1) }
                        Spacer(Modifier.width(10.dp))
                        StockAdjustButton(icon = Icons.Default.Add) { persist(newStock = stock + 1) }
                        Spacer(Modifier.weight(1f))
                        OutlinedButton(
                            onClick = { showPurchaseDialog = true },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream)
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(7.dp))
                            Text("Покупка")
                        }
                    }

                    if (stock == 1) {
                        StockWarning("Залишилась 1 лінза — час купити нові.")
                    } else if (stock == 0) {
                        StockWarning("Лінз немає — додайте нову покупку.")
                    }
                }
            }

            // Main replacement action is placed directly below the stock card.
            Button(
                onClick = {
                    if (stock >= 2) {
                        val newStock = stock - 2
                        val now = System.currentTimeMillis()
                        persist(newStart = now, newStock = newStock)
                        if (newStock == 1) ReminderNotifications.showPurchaseReminder(context)
                        if (newStock == 0) ReminderNotifications.showEmptyReminder(context)
                    }
                },
                enabled = stock >= 2,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Cream, contentColor = Ink)
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (startMs == 0L) "Замінити та почати цикл" else "Замінити лінзи • списати 2", fontWeight = FontWeight.Bold)
            }

            if (startMs == 0L) {
                OutlinedButton(
                    onClick = { persist(newStart = System.currentTimeMillis()) },
                    enabled = stock >= 2,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream)
                ) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Встановити дату без списання")
                }
            }

            Text(
                "Сповіщення працюють після закриття застосунку. Для Android 13+ дозвольте сповіщення.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            Spacer(Modifier.height(8.dp))
        }
    }

    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = { Text("Налаштування") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Період заміни", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Box {
                        OutlinedButton(
                            onClick = { showPeriodMenu = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream)
                        ) {
                            Text("$periodDays днів")
                            Spacer(Modifier.weight(1f))
                            Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        DropdownMenu(expanded = showPeriodMenu, onDismissRequest = { showPeriodMenu = false }) {
                            listOf(7, 14, 30, 60, 90).forEach { days ->
                                DropdownMenuItem(
                                    text = { Text("$days днів") },
                                    onClick = {
                                        showPeriodMenu = false
                                        val start = if (startMs == 0L) System.currentTimeMillis() else startMs
                                        persist(newStart = start, newPeriod = days)
                                    }
                                )
                            }
                        }
                    }

                    Text("Час нагадування", color = Color.White, fontWeight = FontWeight.SemiBold)
                    OutlinedButton(
                        onClick = { showReminderTimePicker = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream)
                    ) {
                        Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("%02d:%02d".format(reminderHour, reminderMinute))
                        Spacer(Modifier.weight(1f))
                    }

                    Text(
                        if (systemAlarmTime != null) {
                            "Системний будильник: ${formatDateTime(systemAlarmTime)}\nУ день заміни сповіщення буде синхронізовано з ним."
                        } else {
                            "Активного системного будильника немає. Використовується заданий час нагадування."
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showSettingsDialog = false }) { Text("Готово") }
            }
        )
    }

    if (showPurchaseDialog) {
        AlertDialog(
            onDismissRequest = { showPurchaseDialog = false },
            title = { Text("Нова покупка") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Скільки лінз додати до залишку?")
                    OutlinedTextField(
                        value = purchaseAmount,
                        onValueChange = { purchaseAmount = it.filter(Char::isDigit).take(4) },
                        singleLine = true,
                        label = { Text("Кількість") }
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val amount = purchaseAmount.toIntOrNull() ?: 0
                    if (amount > 0) persist(newStock = stock + amount)
                    showPurchaseDialog = false
                }) { Text("Додати") }
            },
            dismissButton = { OutlinedButton(onClick = { showPurchaseDialog = false }) { Text("Скасувати") } }
        )
    }

    if (showReminderTimePicker) {
        val state = rememberTimePickerState(initialHour = reminderHour, initialMinute = reminderMinute, is24Hour = true)
        AlertDialog(
            onDismissRequest = { showReminderTimePicker = false },
            confirmButton = {
                Button(onClick = {
                    showReminderTimePicker = false
                    val start = if (startMs == 0L) System.currentTimeMillis() else startMs
                    persist(newStart = start, newHour = state.hour, newMinute = state.minute)
                }) { Text("Зберегти") }
            },
            dismissButton = { OutlinedButton(onClick = { showReminderTimePicker = false }) { Text("Скасувати") } },
            text = { TimePicker(state = state) }
        )
    }



}

@Composable
private fun StockAdjustButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.size(48.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
        shape = RoundedCornerShape(15.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun StockWarning(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF302D28)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Notifications, contentDescription = null, tint = Cream, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = Cream, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
    }
}

private fun calculateNext(startMs: Long, periodDays: Int, hour: Int, minute: Int): Long {
    val calendar = Calendar.getInstance().apply { timeInMillis = startMs }
    calendar.add(Calendar.DAY_OF_YEAR, periodDays)
    calendar.set(Calendar.HOUR_OF_DAY, hour)
    calendar.set(Calendar.MINUTE, minute)
    calendar.set(Calendar.SECOND, 0)
    calendar.set(Calendar.MILLISECOND, 0)
    while (calendar.timeInMillis <= System.currentTimeMillis()) {
        calendar.add(Calendar.DAY_OF_YEAR, periodDays)
    }
    return calendar.timeInMillis
}

private fun formatDateTime(timeMs: Long): String =
    SimpleDateFormat("dd.MM.yyyy • HH:mm", Locale.getDefault()).format(Date(timeMs))

object ReminderScheduler {
    fun getNextSystemAlarmTime(context: Context): Long? {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return alarmManager.nextAlarmClock?.triggerTime
    }

    fun getNextReplacementTime(
        context: Context,
        startMs: Long,
        periodDays: Int,
        notificationHour: Int,
        notificationMinute: Int
    ): Long {
        val dueDate = calculateNext(startMs, periodDays, 0, 0)
        val systemAlarm = getNextSystemAlarmTime(context)
        val hour = systemAlarm?.let { Calendar.getInstance().apply { timeInMillis = it }.get(Calendar.HOUR_OF_DAY) } ?: notificationHour
        val minute = systemAlarm?.let { Calendar.getInstance().apply { timeInMillis = it }.get(Calendar.MINUTE) } ?: notificationMinute
        return Calendar.getInstance().apply {
            timeInMillis = dueDate
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun syncReplacementWithSystemAlarm(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val startMs = prefs.getLong(KEY_START, 0L)
        if (startMs <= 0L) return

        val periodDays = prefs.getInt(KEY_PERIOD, 30)
        val notificationHour = prefs.getInt(KEY_HOUR, 9)
        val notificationMinute = prefs.getInt(KEY_MINUTE, 0)
        scheduleReplacement(context, startMs, periodDays, notificationHour, notificationMinute)
    }

    fun scheduleReplacement(
        context: Context,
        startMs: Long,
        periodDays: Int,
        notificationHour: Int,
        notificationMinute: Int
    ) {
        val triggerAt = getNextReplacementTime(context, startMs, periodDays, notificationHour, notificationMinute)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).setAction(ACTION_REPLACE)
        val pending = PendingIntent.getBroadcast(
            context, REQUEST_CODE_REPLACE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pending)
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
    }

}
object ReminderNotifications {
    fun showReplacement(context: Context) {
        notify(context, REQUEST_CODE_REPLACE, "Час замінити лінзи", "Замініть лінзи та натисніть «Замінити лінзи • списати 2», щоб оновити залишок.")
    }

    fun showPurchaseReminder(context: Context) {
        notify(context, REQUEST_CODE_BUY, "Час купити лінзи", "Залишилася 1 лінза. Додайте нову покупку в Lens Reminder.")
    }

    fun showEmptyReminder(context: Context) {
        notify(context, REQUEST_CODE_BUY + 1, "Лінзи закінчилися", "Додайте нову покупку перед наступною заміною.")
    }

    private fun notify(context: Context, id: Int, title: String, text: String) {
        createNotificationChannel(context)
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = android.app.Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_lens_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(id, notification)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            ACTION_REPLACE -> {
                ReminderNotifications.showReplacement(context)
                // Immediately bind the next replacement reminder to the next system alarm.
                ReminderScheduler.syncReplacementWithSystemAlarm(context)
            }
            else -> Unit
        }
    }
}

private fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Нагадування про лінзи",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Нагадування про заміну та покупку лінз"
            }
        )
    }
}

