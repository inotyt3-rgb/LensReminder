# Lens Reminder v1.3 — GitHub Actions

## Як зібрати APK

1. Завантажте всі файли цього проєкту в репозиторій GitHub.
2. Відкрийте **Actions**.
3. Виберіть **Build LensReminder APK**.
4. Натисніть **Run workflow** або дочекайтеся автоматичного запуску після push у `main`.
5. Після успішної збірки відкрийте run і завантажте artifact **LensReminder-v1.3-debug**.

## Важливо

Це debug APK для тестування. Референсне зображення не потрібне для збірки.
