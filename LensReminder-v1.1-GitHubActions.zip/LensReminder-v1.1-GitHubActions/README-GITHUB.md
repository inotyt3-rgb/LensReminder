# Швидкий запуск через GitHub

### 1. Створіть репозиторій

На GitHub створіть новий репозиторій, наприклад `LensReminder`.

### 2. Завантажте файли

Завантажте **весь вміст** цього ZIP у корінь репозиторію. Важливо не загубити папку:

`.github/workflows/build-apk.yml`

### 3. Запустіть збірку

Відкрийте:

**Actions → Build LensReminder APK → Run workflow**

Після завершення відкрийте успішний запуск і внизу сторінки знайдіть:

**Artifacts → LensReminder-v1.1-debug**

У ZIP буде `app-debug.apk`.

GitHub Actions автоматично встановить JDK 17, Gradle 8.9 та Android SDK 35.
