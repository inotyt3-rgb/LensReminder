package com.example.lensreminder

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val CHANNEL_ID = "lens_reminders"
private const val PREFS = "lens_reminder_prefs"
private const val KEY_START = "start_ms"
private const val KEY_PERIOD = "period_days"
private const val KEY_HOUR = "hour"
private const val KEY_MINUTE = "minute"
private const val REQUEST_CODE = 4401

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            LensReminderTheme {
                LensApp()
            }
        }
    }
}

@Composable
private fun LensReminderTheme(content: @Composable () -> Unit) {
    val colors = androidx.compose.material3.darkColorScheme(
        primary = Color(0xFF8B7CFF),
        secondary = Color(0xFF63D7FF),
        background = Color(0xFF101114),
        surface = Color(0xFF191A1F),
        surfaceVariant = Color(0xFF24262D)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@Composable
private fun LensApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var periodDays by remember { mutableStateOf(prefs.getInt(KEY_PERIOD, 30)) }
    var reminderHour by remember { mutableStateOf(prefs.getInt(KEY_HOUR, 9)) }
    var reminderMinute by remember { mutableStateOf(prefs.getInt(KEY_MINUTE, 0)) }
    var startMs by remember { mutableStateOf(prefs.getLong(KEY_START, 0L)) }
    var showPeriodMenu by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }

    fun saveAndSchedule(newStart: Long = startMs, newPeriod: Int = periodDays, newHour: Int = reminderHour, newMinute: Int = reminderMinute) {
        startMs = newStart
        periodDays = newPeriod
        reminderHour = newHour
        reminderMinute = newMinute
        prefs.edit()
            .putLong(KEY_START, newStart)
            .putInt(KEY_PERIOD, newPeriod)
            .putInt(KEY_HOUR, newHour)
            .putInt(KEY_MINUTE, newMinute)
            .apply()
        if (newStart > 0L) {
            ReminderScheduler.schedule(context, newStart, newPeriod, newHour, newMinute)
        }
    }

    val nextDate = if (startMs > 0L) calculateNext(startMs, periodDays, reminderHour, reminderMinute) else null
    val dateText = nextDate?.let { formatDateTime(it) } ?: "Нагадування ще не налаштовано"

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Visibility, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Lens Reminder", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Нагадування про заміну лінз", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Наступна заміна", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                    Text(dateText, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                    if (nextDate != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(6.dp))
                            Text("Нагадування о %02d:%02d".format(reminderHour, reminderMinute))
                        }
                    }
                }
            }

            Text("Налаштування", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Період заміни")
                    BoxWithDropdown(
                        label = "$periodDays днів",
                        expanded = showPeriodMenu,
                        onExpandedChange = { showPeriodMenu = it },
                        options = listOf(7, 14, 30, 60, 90),
                        onSelect = {
                            showPeriodMenu = false
                            val start = if (startMs == 0L) System.currentTimeMillis() else startMs
                            saveAndSchedule(start, it, reminderHour, reminderMinute)
                        }
                    )

                    Text("Час нагадування")
                    OutlinedButton(onClick = { showTimePicker = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Alarm, contentDescription = null)
                        Spacer(Modifier.size(8.dp))
                        Text("%02d:%02d".format(reminderHour, reminderMinute))
                    }
                }
            }

            Button(
                onClick = {
                    val now = System.currentTimeMillis()
                    saveAndSchedule(now, periodDays, reminderHour, reminderMinute)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text(if (startMs == 0L) "Встановити дату заміни" else "Замінити лінзи сьогодні")
            }

            OutlinedButton(
                onClick = {
                    val now = System.currentTimeMillis()
                    saveAndSchedule(now, periodDays, reminderHour, reminderMinute)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("Почати новий цикл")
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(8.dp))
                Text("Нагадування працює навіть після закриття застосунку.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    if (showTimePicker) {
        val state = rememberTimePickerState(initialHour = reminderHour, initialMinute = reminderMinute, is24Hour = true)
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                Button(onClick = {
                    showTimePicker = false
                    val start = if (startMs == 0L) System.currentTimeMillis() else startMs
                    saveAndSchedule(start, periodDays, state.hour, state.minute)
                }) { Text("Зберегти") }
            },
            dismissButton = { OutlinedButton(onClick = { showTimePicker = false }) { Text("Скасувати") } },
            text = { TimePicker(state = state) }
        )
    }
}

@Composable
private fun BoxWithDropdown(
    label: String,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    options: List<Int>,
    onSelect: (Int) -> Unit
) {
    androidx.compose.material3.ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = onExpandedChange,
        modifier = Modifier.fillMaxWidth()
    ) {
        androidx.compose.material3.OutlinedTextField(
            value = label,
            onValueChange = {},
            readOnly = true,
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { onExpandedChange(false) }) {
            options.forEach { days ->
                DropdownMenuItem(text = { Text("$days днів") }, onClick = { onSelect(days) })
            }
        }
    }
}

private fun calculateNext(startMs: Long, periodDays: Int, hour: Int, minute: Int): Long {
    val calendar = Calendar.getInstance().apply { timeInMillis = startMs }
    calendar.add(Calendar.DAY_OF_YEAR, periodDays)
    calendar.set(Calendar.HOUR_OF_DAY, hour)
    calendar.set(Calendar.MINUTE, minute)
    calendar.set(Calendar.SECOND, 0)
    calendar.set(Calendar.MILLISECOND, 0)
    while (calendar.timeInMillis <= System.currentTimeMillis()) {
        calendar.add(Calendar.DAY_OF_YEAR, periodDays)
    }
    return calendar.timeInMillis
}

private fun formatDateTime(timeMs: Long): String =
    SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.getDefault()).format(Date(timeMs))

object ReminderScheduler {
    fun schedule(context: Context, startMs: Long, periodDays: Int, hour: Int, minute: Int) {
        val triggerAt = calculateNext(startMs, periodDays, hour, minute)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pending)
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        createNotificationChannel(context)
        val notification = android.app.Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Час замінити лінзи")
            .setContentText("Перевірте та замініть контактні лінзи, якщо настав ваш цикл.")
            .setAutoCancel(true)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            manager.notify(REQUEST_CODE, notification)
        }
    }
}

private fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Нагадування про лінзи", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Нагадування про заплановану заміну контактних лінз"
            }
        )
    }
}
