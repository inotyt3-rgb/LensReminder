# Lens Reminder v1.4

- Системна синхронізація нагадування: застосунок орієнтується на найближчий активний системний будильник Android через `AlarmManager.nextAlarmClock`.
- Власний будильник у Lens Reminder не створюється.
- Якщо активного системного будильника немає, використовується заданий у налаштуваннях час нагадування.
- При зміні системного будильника час наступного нагадування синхронізується повторно.
- Тестове сповіщення та окремі налаштування тесту повністю прибрані.
- Блок «Швидкі дії» повністю прибраний.
- Основна кнопка «Замінити лінзи» переміщена безпосередньо під картку «Залишок».
- Налаштування більше не займають місце на головному екрані: вони відкриваються окремим меню після натискання кнопки налаштувань у верхній панелі.
- Верхня панель отримала відступ від системного status bar, тому «Lens Reminder» і кнопка налаштувань не перекриваються системною панеллю.
- Кількість лінз, цикл заміни та нагадування про покупку збережені.


## v1.5 — Віджет

Додано віджет Lens Reminder для головного екрана Android. Дані беруться з того самого локального сховища, що й основний застосунок; окремої бази даних немає.

Підтримуються адаптивні варіанти 2×1, 2×2 та 4×1. Віджет показує залишок лінз і наступну дату заміни, а для широкого варіанта — також час та статус запасу. При залишку 1 лінза використовується попереджувальний стан, при 0 — стан відсутності лінз. Натискання на віджет відкриває Lens Reminder. Після зміни залишку або налаштувань віджет оновлюється автоматично.


## v1.5.1 Widget stability fix
- Improved AppWidgetProvider error handling.
- Removed previewLayout/targetCell dependency from widget metadata.
- Added safe fallback widget layout.
- Simplified RemoteViews layouts for launcher compatibility.

## Widget dynamic colors
- Android 12+ uses the system Material You dynamic palette derived from the current wallpaper/system color selection.
- Widget surface, outline, accent, secondary text and warning/error accents adapt to the system palette.
- Android 8-11 keeps the existing fallback palette.
- The main app UI is not changed by this feature.
