# Build fixes

This revision aligns the Android build toolchain with API 35:

- Android Gradle Plugin: **8.7.3** (official API 35 support)
- Gradle: **8.9**
- JDK: **17**
- Android platform: **android-35**
- Build Tools: **35.0.0**
- The workflow installs SDK 35 explicitly with `sdkmanager`.
- Removed `android.suppressUnsupportedCompileSdk=35`; it is no longer needed.
- Build uses `--stacktrace` so a future CI failure contains useful diagnostics.

The app source itself was left unchanged.
