# Lens Reminder v1.4 — GitHub Actions

## Як зібрати APK

1. Завантажте всі файли цього проєкту в репозиторій GitHub.
2. Відкрийте **Actions**.
3. Виберіть **Build LensReminder APK**.
4. Натисніть **Run workflow** або дочекайтеся автоматичного запуску після push у `main`.
5. Після успішної збірки відкрийте run і завантажте artifact **LensReminder-v1.5-widget-debug**.

## Важливо

Це debug APK для тестування. Референсне зображення не потрібне для збірки.


## Віджет

Після встановлення APK відкрийте вибір віджетів на головному екрані Android і додайте **Lens Reminder**. Віджет можна змінювати за розміром; застосунок автоматично використовує компактний, середній або широкий макет.


## v1.5.1 Widget stability fix
- Improved AppWidgetProvider error handling.
- Removed previewLayout/targetCell dependency from widget metadata.
- Added safe fallback widget layout.
- Simplified RemoteViews layouts for launcher compatibility.
