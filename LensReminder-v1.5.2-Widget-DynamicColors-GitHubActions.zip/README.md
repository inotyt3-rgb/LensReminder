# LensReminder v1.1 — GitHub Actions build

Android app for contact-lens replacement reminders.

## Build APK on GitHub

1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (including `.github`).
3. Open **Actions** → **Build LensReminder APK**.
4. Click **Run workflow** (or push to `main`).
5. Wait for the job to finish.
6. Open the completed workflow run and download the artifact **LensReminder-v1.1-debug**.
7. Extract the ZIP and install `app-debug.apk` on Android.

The workflow installs JDK 17, Gradle 8.9, Android SDK 35 and Build Tools 35.0.0 automatically, so no AndroidIDE/Android Studio is required on the phone.

## Features

- Ukrainian Material 3 dark UI
- Select replacement period: 7 / 14 / 30 / 60 / 90 days
- Select reminder time
- Save a replacement cycle
- Schedule an Android notification with AlarmManager
- Works after the app is closed
- Requests notification permission on Android 13+


## v1.5.1 Widget stability fix
- Improved AppWidgetProvider error handling.
- Removed previewLayout/targetCell dependency from widget metadata.
- Added safe fallback widget layout.
- Simplified RemoteViews layouts for launcher compatibility.

### v1.5.2
The Lens Reminder widget uses Android 12+ Material You dynamic system colors, including wallpaper-derived palette variants. The application UI itself is unchanged.
