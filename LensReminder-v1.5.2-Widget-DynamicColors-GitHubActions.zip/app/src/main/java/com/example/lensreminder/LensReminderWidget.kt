package com.example.lensreminder

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LensReminderWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        appWidgetIds.forEach { updateWidgetSafely(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        updateWidgetSafely(context, appWidgetManager, appWidgetId)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        super.onDeleted(context, appWidgetIds)
    }

    override fun onEnabled(context: Context) {
        updateAll(context)
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, LensReminderWidget::class.java)
            manager.getAppWidgetIds(component).forEach {
                updateWidgetSafely(context, manager, it)
            }
        }

        private fun updateWidgetSafely(
            context: Context,
            manager: AppWidgetManager,
            appWidgetId: Int
        ) {
            try {
                updateWidget(context, manager, appWidgetId)
            } catch (_: Throwable) {
                // Never let a widget exception leave the provider in a broken state.
                showFallback(context, manager, appWidgetId)
            }
        }

        private fun updateWidget(
            context: Context,
            manager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val options = manager.getAppWidgetOptions(appWidgetId)
            val width = options.getInt(
                AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,
                110
            )
            val height = options.getInt(
                AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,
                55
            )

            val layout = when {
                height >= 170 && width >= 145 -> R.layout.widget_2x2
                width >= 230 -> R.layout.widget_4x1
                else -> R.layout.widget_2x1
            }

            val views = RemoteViews(context.packageName, layout)
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

            val stock = prefs.getInt(KEY_STOCK, 0)
            val startMs = prefs.getLong(KEY_START, 0L)
            val periodDays = prefs.getInt(KEY_PERIOD, 30)
            val hour = prefs.getInt(KEY_HOUR, 9)
            val minute = prefs.getInt(KEY_MINUTE, 0)

            val next = if (startMs > 0L && periodDays > 0) {
                ReminderScheduler.getNextReplacementTime(
                    context, startMs, periodDays, hour, minute
                )
            } else {
                null
            }

            val background = when {
                stock <= 0 -> R.drawable.widget_bg_empty
                stock == 1 -> R.drawable.widget_bg_warning
                else -> R.drawable.widget_bg
            }

            views.setInt(R.id.widget_root, "setBackgroundResource", background)
            val stockText = if (layout == R.layout.widget_2x2) {
                "$stock\nшт."
            } else {
                "$stock шт."
            }
            views.setTextViewText(R.id.widget_stock, stockText)

            views.setTextViewText(
                R.id.widget_next,
                next?.let {
                    if (layout == R.layout.widget_4x1) {
                        formatDateTime(it)
                    } else {
                        formatDate(it)
                    }
                } ?: "Дата не встановлена"
            )

            if (layout == R.layout.widget_4x1) {
                val status = when {
                    stock <= 0 -> "Потрібно купити"
                    stock == 1 -> "Купіть лінзи"
                    else -> "Усе добре"
                }
                val statusColor = when {
                    stock <= 0 -> context.getColor(R.color.widget_error)
                    stock == 1 -> context.getColor(R.color.widget_warning)
                    else -> context.getColor(R.color.widget_accent_alt)
                }
                views.setTextViewText(R.id.widget_status, status)
                views.setTextColor(R.id.widget_status, statusColor)
            }

            val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                appWidgetId,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
            manager.updateAppWidget(appWidgetId, views)
        }

        private fun showFallback(
            context: Context,
            manager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_fallback)
            views.setTextViewText(R.id.widget_fallback_text, "Lens Reminder")
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pending = PendingIntent.getActivity(
                context,
                appWidgetId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_fallback_root, pending)
            manager.updateAppWidget(appWidgetId, views)
        }

        private fun formatDate(timeMs: Long): String =
            SimpleDateFormat("dd MMM yyyy", Locale("uk", "UA")).format(Date(timeMs))

        private fun formatDateTime(timeMs: Long): String =
            SimpleDateFormat("dd MMM yyyy • HH:mm", Locale("uk", "UA")).format(Date(timeMs))
    }
}
